<?php
return [
    'db' => [
        'host' => 'keni.ba',
        'user' => 'keniba_scandiweb',
        'password' => 'scandiweb123',
        'dbname' => 'keniba_scandiweb',
    ]
];
